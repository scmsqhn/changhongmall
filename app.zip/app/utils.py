#!/usr/bin/env python
# -*- coding: utf-8 -*-

def prts(i):
    pass
#   print"[x] ", str(i), "= ", i, ";type=", type(i), "/r/n"
    
def prt(*inp):
    [prts(i) for i in inp]
